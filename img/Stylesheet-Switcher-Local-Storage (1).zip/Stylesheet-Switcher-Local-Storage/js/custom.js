$(document).ready(function () {
    $("#colorpick").styleSwitcher();
});
